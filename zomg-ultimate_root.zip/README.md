# ZOMG Ultimate (Root ZIP)

This ZIP is structured so that `build.gradle` is at the root after unzipping.

## Build locally
```
gradle build
```
JARs appear in `build/libs/`.
