# ZOMG Gun Quick
Quick test mod: GunItem and AmmoItem for testing in dev environment.

Drop this into your Fabric workspace and run `gradlew genSources idea` or `gradlew build`.
