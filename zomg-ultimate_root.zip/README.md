# ZOMG Ultimate (1.21.8 Scaffold)

This is a *minimal* Fabric mod scaffold pinned to **Minecraft 1.21.8**, **Java 21**, **Fabric Loader 0.16.7**, **Fabric API 0.134.0+1.21.8**.

## Build (locally)
- Java 21 required.
- Run: `gradle build`
- Output: `build/libs/`

## GitHub Actions
Use Java 21 in setup-java.

Once this builds, you can start dropping in your actual mod code.
