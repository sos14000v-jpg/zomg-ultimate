package com.example.zomg;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.LiteralText;
import net.minecraft.item.ItemStack;

import static net.minecraft.server.command.CommandManager.literal;
import static net.minecraft.server.command.CommandManager.argument;

public class ZomgCommands {
    public static void register(com.mojang.brigadier.CommandDispatcher<ServerCommandSource> dispatcher){
        dispatcher.register(literal("giveammo")
            .then(argument("amount", IntegerArgumentType.integer(1))
                .executes(ctx -> {
                    int amt = IntegerArgumentType.getInteger(ctx, "amount");
                    ServerCommandSource src = ctx.getSource();
                    ServerPlayerEntity player = src.getPlayer();
                    if (player != null) {
                        ItemStack s = new ItemStack(HelloMod.AMMO, amt);
                        if (!player.getInventory().insertStack(s)) {
                            player.dropItem(s, false);
                        }
                        src.sendFeedback(new LiteralText("Gave " + amt + " ammo."), false);
                        return 1;
                    }
                    return 0;
                })));
    }
}
