package com.example.zomg;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;

public class HelloMod implements ModInitializer {
    public static final String MODID = "zomg_gun_quick";
    public static Item GUN;
    public static Item AMMO;

    @Override
    public void onInitialize() {
        GUN = Registry.register(Registry.ITEM, id("gun"), new GunItem(new Item.Settings().maxCount(1).group(ItemGroup.COMBAT)));
        AMMO = Registry.register(Registry.ITEM, id("ammo"), new AmmoItem(new Item.Settings().maxCount(64).group(ItemGroup.MISC)));

        // simple command to give ammo in dev environment - registered via Fabric Command API v2
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            ZomgCommands.register(dispatcher);
        });
    }

    public static Identifier id(String path){
        return new Identifier(MODID, path);
    }
}
