package com.example.zomg;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HelloMod implements ModInitializer {
    public static final String MODID = "zomg_ultimate";
    public static final Logger LOGGER = LoggerFactory.getLogger(MODID);

    @Override
    public void onInitialize() {
        LOGGER.info("[ZOMG Ultimate] Hello from 1.21.8 scaffold! Build OK ✅");
    }
}
