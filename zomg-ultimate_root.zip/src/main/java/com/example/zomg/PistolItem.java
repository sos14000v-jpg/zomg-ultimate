package com.example.zomg;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class PistolItem extends Item {
    public PistolItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);

        if (!world.isClient) {
            ArrowEntity arrow = new ArrowEntity(world, user);
            arrow.setVelocity(user, user.getPitch(), user.getYaw(), 0.0F, 3.2F, 1.0F);
            arrow.setDamage(6.0D); // 대미지
            arrow.setPunch(0);     // 넉백 0
            world.spawnEntity(arrow);
        }
        world.playSound(user, user.getX(), user.getY(), user.getZ(), SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.3F, 1.6F);
        user.getItemCooldownManager().set(this, 8); // 0.4초 쿨다운(틱 20=1초)
        return TypedActionResult.success(stack, world.isClient);
    }
}
