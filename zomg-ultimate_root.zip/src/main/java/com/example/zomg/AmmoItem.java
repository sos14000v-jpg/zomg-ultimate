package com.example.zomg;

import net.minecraft.item.Item;

public class AmmoItem extends Item {
    public AmmoItem(Settings s){
        super(s);
    }
}
