package com.example.zomg;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.projectile.SnowballEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.UseAction;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

public class GunItem extends Item {
    public GunItem(Settings s){
        super(s);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        return ActionResult.PASS;
    }

    @Override
    public ActionResult use(World world, net.minecraft.entity.player.PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        // try to find one ammo in inventory
        boolean found = false;
        for (int i=0;i<user.getInventory().size();i++){
            ItemStack inv = user.getInventory().getStack(i);
            if (inv.getItem() == HelloMod.AMMO && inv.getCount() > 0) {
                found = true;
                if (!world.isClient) {
                    inv.decrement(1);
                    // spawn a snowball projectile as the bullet
                    SnowballEntity sbe = new SnowballEntity(world, user);
                    sbe.setVelocity(user, user.getPitch(), user.getYaw(), 0.0F, 3.0F, 1.0F);
                    world.spawnEntity(sbe);
                    if (user instanceof ServerPlayerEntity) {
                        ((ServerPlayerEntity) user).incrementStat(Stats.USED.getOrCreateStat(this));
                    }
                    world.playSound(null, user.getBlockPos(), SoundEvents.ENTITY_ARROW_SHOOT, SoundCategory.PLAYERS, 1.0F, 1.0F);
                }
                break;
            }
        }
        if (!found) {
            if (!world.isClient) {
                user.sendMessage(new net.minecraft.text.LiteralText("No ammo! Use /giveammo <amount> to get ammo."), false);
            }
            return ActionResult.FAIL;
        }
        return ActionResult.success(world.isClient);
    }

    @Override
    public UseAction getUseAction(ItemStack stack) {
        return UseAction.NONE;
    }
}
