# ZOMG Ultimate (Build-Ready)

Fabric mod template to upload to GitHub and build a JAR with Actions.

## Local build
If you have Gradle installed:
```
gradle build
```
JARs will appear in `build/libs/`.
